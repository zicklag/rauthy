import{a as t}from"../chunks/entry.BNUjxTOt.js";export{t as start};
