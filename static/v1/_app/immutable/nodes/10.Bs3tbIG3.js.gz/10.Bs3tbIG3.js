import"../chunks/disclose-version.BDr9Qe-U.js";import"../chunks/legacy.CNpbjrm0.js";import{A as t}from"../chunks/AdminMainPre.C2lfKgCW.js";function e(o){t(o,{selected:"Docs"})}export{e as component};
